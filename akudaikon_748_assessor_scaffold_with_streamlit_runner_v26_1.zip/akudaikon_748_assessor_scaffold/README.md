# Akudaikon | Part 748 Assessment Assistant (Scaffold)

Starter scaffold for an Azure-hostable app that helps collect evidence and evaluate controls against **12 CFR Part 748**.

## Contents
- `frontend/` Streamlit UI (intake + module workflow)
- `api/` FastAPI backend (evidence upload stub)
- `control_library/` YAML modules (starting with Policies & Procedures)
- `infra/` Azure Bicep placeholder
- `docs/` draft data handling & security statement

## Modules currently included
- Policies & Procedures
- Governance
- Asset Inventory
- Risk Assessment
- Controls Testing
- Corrective Actions
- Training
- Incident Response (incl. 72-hour NCUA cyber incident notification)
- Third-Party Risk Management
- Business Continuity / Disaster Recovery
- Vulnerability & Patch Management
- Antivirus & Antimalware Controls
- Access Controls
- Network Security
- Data Leak Protection
- Change & Configuration Management
- Monitoring

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run frontend/streamlit_app.py
```
