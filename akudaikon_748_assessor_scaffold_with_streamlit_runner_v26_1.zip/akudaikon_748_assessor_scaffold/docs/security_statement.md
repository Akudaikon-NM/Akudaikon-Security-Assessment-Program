# Data Handling & Security Statement (Draft)

## Recommended default: customer-hosted deployment
- Deploy into the credit union’s Azure tenant/subscription.
- Evidence and assessment data remain in the credit union’s environment.
- Access for Akudaikon staff is via Entra ID B2B guest access with MFA + least privilege.

## Baseline controls (both models)
- Encryption in transit and at rest
- Key Vault for secrets/keys; optional customer-managed keys
- Malware scanning + file type allowlist on upload
- Audit logging for all evidence access and exports
- Data minimization + defined retention/secure deletion

**Disclaimer:** Akudaikon is an independent consultant and does not act on behalf of the NCUA or any regulator.
