import streamlit as st
import yaml
from pathlib import Path
from typing import Dict, Any

st.set_page_config(page_title="Akudaikon | Part 748 Intake (Scaffold)", layout="wide")
st.title("Akudaikon | Part 748 Intake (Scaffold)")
st.caption("Evidence-led control assessment aligned to 12 CFR Part 748 and related NCUA guidance.")

MODULE_DIR = Path(__file__).resolve().parents[1] / "control_library" / "modules"

@st.cache_data
def load_modules() -> Dict[str, Any]:
    out = {}
    for p in MODULE_DIR.glob("*.yaml"):
        with open(p, "r", encoding="utf-8") as f:
            out[p.stem] = yaml.safe_load(f)
    return out

modules = load_modules()

with st.sidebar:
    st.header("Client Intake")
    st.text_input("Credit union name", key="cu_name")
    st.text_input("Assets (optional)", key="assets")
    st.selectbox("Primary regulator", ["NCUA", "State", "Dual"], index=0, key="regulator")
    st.radio("Deployment model", ["Customer-hosted (recommended)", "Consultant-hosted"], index=0, key="hosting")

st.subheader("Assessment Modules")
module_key = st.selectbox("Select a module", options=list(modules.keys()))
module = modules[module_key]

st.markdown(f"### {module['title']}")
st.write(module.get("description",""))

tabs = st.tabs(["Questions", "Evidence Requests", "Findings & Remediation", "Export (stub)"])

with tabs[0]:
    for i, q in enumerate(module["questions"], start=1):
        st.markdown(f"**Q{i}. {q['prompt']}**")
        st.caption(f"Reference: {q.get('reference','')}")
        st.radio("Response", ["Yes", "No", "Partial", "N/A"], key=f"resp_{i}", horizontal=True)
        st.text_area("Notes / evidence summary", key=f"notes_{i}")

with tabs[1]:
    for i, q in enumerate(module["questions"], start=1):
        st.markdown(f"**Evidence for Q{i}**")
        for ev in q.get("evidence_requests", []):
            st.write(f"- {ev}")
        st.file_uploader("Upload files (stub)", accept_multiple_files=True, key=f"upl_{i}")

with tabs[2]:
    st.markdown("#### Positive / negative finding patterns (starter)")
    for f in module.get("finding_patterns", []):
        st.markdown(f"- **{f['type'].title()}**: {f['text']}")
        if f.get("remediation"):
            st.caption("Remediation starter:")
            for r in f["remediation"]:
                st.write(f"  - {r}")

with tabs[3]:
    st.info("Export will generate a board-ready summary + examiner-ready evidence index (to be implemented).")
    st.button("Generate PDF (stub)")
