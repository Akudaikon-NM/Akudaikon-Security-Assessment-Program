from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors


def _summary_counts(answers: Dict[str, Any]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for qid, a in answers.items():
        rating = (a or {}).get("rating") or "Unrated"
        counts[rating] = counts.get(rating, 0) + 1
    return counts


def build_pdf_report(
    out_path: Path,
    assessment_meta: Dict[str, Any],
    module: Dict[str, Any],
    answers: Dict[str, Any],
) -> Path:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(out_path), pagesize=LETTER, title="Assessment Report")
    styles = getSampleStyleSheet()
    story: List[Any] = []

    title = f"{assessment_meta.get('client_name','Client')} — {module.get('title','Module')} Report"
    story.append(Paragraph(title, styles["Title"]))
    story.append(Spacer(1, 10))

    story.append(Paragraph(f"<b>Assessment ID:</b> {assessment_meta.get('assessment_id','')}", styles["Normal"]))
    story.append(Paragraph(f"<b>Date:</b> {assessment_meta.get('date','')}", styles["Normal"]))
    story.append(Paragraph(f"<b>Assessor:</b> {assessment_meta.get('assessor_name','')}", styles["Normal"]))
    story.append(Spacer(1, 10))

    if module.get("description"):
        story.append(Paragraph("<b>Module Description</b>", styles["Heading2"]))
        story.append(Paragraph(str(module.get("description")), styles["Normal"]))
        story.append(Spacer(1, 10))

    # Summary
    counts = _summary_counts(answers)
    story.append(Paragraph("<b>Ratings Summary</b>", styles["Heading2"]))
    data = [["Rating", "Count"]] + [[k, str(v)] for k, v in sorted(counts.items(), key=lambda x: x[0])]
    t = Table(data, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
        ("GRID", (0,0), (-1,-1), 0.5, colors.grey),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("PADDING", (0,0), (-1,-1), 6),
    ]))
    story.append(t)
    story.append(Spacer(1, 14))

    # Details
    story.append(Paragraph("<b>Question Responses</b>", styles["Heading2"]))
    story.append(Spacer(1, 6))

    questions = module.get("questions") or []
    for q in questions:
        qid = str(q.get("id", ""))
        prompt = str(q.get("prompt", ""))
        ref = q.get("reference", "")
        section = q.get("section", "")
        ev_reqs = q.get("evidence_requests") or []
        a = answers.get(qid, {}) or {}

        story.append(Paragraph(f"<b>{qid}</b> {('— ' + section) if section else ''}", styles["Heading3"]))
        story.append(Paragraph(prompt, styles["Normal"]))
        if ref:
            story.append(Paragraph(f"<b>Reference:</b> {ref}", styles["Normal"]))
        story.append(Paragraph(f"<b>Rating:</b> {a.get('rating','Unrated')}", styles["Normal"]))
        if a.get("notes"):
            story.append(Paragraph(f"<b>Notes:</b> {a.get('notes')}", styles["Normal"]))

        if ev_reqs:
            story.append(Paragraph("<b>Requested Evidence:</b>", styles["Normal"]))
            for item in ev_reqs:
                story.append(Paragraph(f"• {item}", styles["Normal"]))

        files = a.get("evidence_files") or []
        if files:
            story.append(Paragraph("<b>Uploaded Evidence:</b>", styles["Normal"]))
            for f in files:
                story.append(Paragraph(f"• {f}", styles["Normal"]))

        story.append(Spacer(1, 10))

    doc.build(story)
    return out_path
