# Akudaikon Part 748 Assessor — Streamlit Module Runner

This is a lightweight Streamlit "Module Runner" that loads assessment modules from:
- `../control_library/modules/*.yaml`

It lets you:
- Select a module
- Capture ratings + notes per question
- Upload evidence files per question
- Export assessment JSON
- Generate a simple PDF report

## Run locally

From the repo root:

```bash
pip install -r streamlit_runner/requirements.txt
streamlit run streamlit_runner/app.py
```

## Where outputs go

- JSON exports: `outputs/exports/`
- Evidence uploads: `outputs/evidence/<assessment_id>/<module_id>/<question_id>/`
- PDF reports: `outputs/reports/`
