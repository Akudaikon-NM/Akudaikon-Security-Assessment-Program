from __future__ import annotations

import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import streamlit as st

from module_loader import load_modules
from reporting import build_pdf_report


ROOT = Path(__file__).resolve().parent.parent
MODULES_DIR = ROOT / "control_library" / "modules"
OUTPUTS_DIR = ROOT / "outputs"
EVIDENCE_DIR = OUTPUTS_DIR / "evidence"
EXPORTS_DIR = OUTPUTS_DIR / "exports"
REPORTS_DIR = OUTPUTS_DIR / "reports"

st.set_page_config(page_title="Akudaikon 748 Assessor — Module Runner", layout="wide")

st.title("Akudaikon Part 748 Assessor — Module Runner")

modules = load_modules(MODULES_DIR)
if not modules:
    st.error(f"No modules found in {MODULES_DIR}.")
    st.stop()

# Sidebar: assessment meta
with st.sidebar:
    st.header("Assessment Info")
    client_name = st.text_input("Client name", value=st.session_state.get("client_name",""))
    assessor_name = st.text_input("Assessor name", value=st.session_state.get("assessor_name",""))
    assessment_id = st.text_input("Assessment ID", value=st.session_state.get("assessment_id","") or str(uuid.uuid4())[:8])
    st.session_state["client_name"] = client_name
    st.session_state["assessor_name"] = assessor_name
    st.session_state["assessment_id"] = assessment_id

    st.divider()
    st.header("Select Module")
    mod_labels = [f"{m.title}  •  ({m.module_id})" for m in modules]
    sel = st.selectbox("Module", mod_labels, index=0)
    selected = modules[mod_labels.index(sel)]

# Initialize storage for this module
state_key = f"answers::{assessment_id}::{selected.module_id}"
if state_key not in st.session_state:
    st.session_state[state_key] = {}

answers: Dict[str, Any] = st.session_state[state_key]

# Module header
col1, col2 = st.columns([3,2])
with col1:
    st.subheader(selected.title)
    if selected.description:
        st.caption(selected.description)
with col2:
    st.write("")
    st.write("")
    st.metric("Questions", len(selected.questions))
    st.metric("Rating Scale", ", ".join(selected.rating_scale))

st.divider()

# Render questions
for q in selected.questions:
    qid = str(q.get("id", ""))
    prompt = str(q.get("prompt", ""))
    section = str(q.get("section", "")) if q.get("section") else ""
    reference = str(q.get("reference", "")) if q.get("reference") else ""
    ev_reqs = q.get("evidence_requests") or []

    # Existing
    existing = answers.get(qid, {}) or {}
    rating = existing.get("rating") or "Unrated"
    notes = existing.get("notes") or ""
    evidence_files = existing.get("evidence_files") or []

    with st.expander(f"{qid} — {section if section else 'Question'}", expanded=False):
        st.markdown(prompt)
        if reference:
            st.caption(f"Reference: {reference}")

        # Evidence requests
        if ev_reqs:
            st.markdown("**Requested evidence**")
            for item in ev_reqs:
                st.write(f"• {item}")

        # Inputs
        cols = st.columns([1,2])
        with cols[0]:
            rating_options = ["Unrated"] + selected.rating_scale
            rating = st.selectbox("Rating", rating_options, index=rating_options.index(rating) if rating in rating_options else 0, key=f"rating::{state_key}::{qid}")
        with cols[1]:
            notes = st.text_area("Notes / observations", value=notes, height=110, key=f"notes::{state_key}::{qid}")

        # Upload evidence files
        st.markdown("**Upload evidence** (optional)")
        uploads = st.file_uploader(
            "Add files",
            accept_multiple_files=True,
            key=f"upload::{state_key}::{qid}",
        )

        saved_files = list(evidence_files)
        if uploads:
            dest_dir = EVIDENCE_DIR / assessment_id / selected.module_id / qid
            dest_dir.mkdir(parents=True, exist_ok=True)
            for up in uploads:
                # Use original name; overwrite if same name
                dest = dest_dir / up.name
                dest.write_bytes(up.getbuffer())
                if str(dest.relative_to(ROOT)) not in saved_files:
                    saved_files.append(str(dest.relative_to(ROOT)))
            st.success(f"Saved {len(uploads)} file(s)")

        if saved_files:
            st.markdown("**Evidence on record**")
            for f in saved_files:
                st.write(f"• {f}")

        # Persist to session state
        answers[qid] = {
            "rating": rating,
            "notes": notes,
            "evidence_files": saved_files,
            "reference": reference,
            "section": section,
            "prompt": prompt,
        }

# Actions
st.divider()
a1, a2, a3, a4 = st.columns([1,1,1,2])

meta = {
    "client_name": client_name,
    "assessor_name": assessor_name,
    "assessment_id": assessment_id,
    "date": datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
    "module_id": selected.module_id,
    "module_title": selected.title,
}

assessment_obj = {
    "meta": meta,
    "module": selected.raw,
    "answers": answers,
}

with a1:
    if st.button("Save JSON export", type="primary"):
        EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
        out = EXPORTS_DIR / f"{assessment_id}__{selected.module_id}.json"
        out.write_text(json.dumps(assessment_obj, indent=2), encoding="utf-8")
        st.success(f"Saved: {out.relative_to(ROOT)}")

with a2:
    json_bytes = json.dumps(assessment_obj, indent=2).encode("utf-8")
    st.download_button(
        label="Download JSON",
        data=json_bytes,
        file_name=f"{assessment_id}__{selected.module_id}.json",
        mime="application/json",
    )

with a3:
    if st.button("Generate PDF report"):
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        out_pdf = REPORTS_DIR / f"{assessment_id}__{selected.module_id}.pdf"
        build_pdf_report(out_pdf, meta, selected.raw, answers)
        st.success(f"Generated: {out_pdf.relative_to(ROOT)}")

with a4:
    st.info(
        "Tip: Start with the **Security Controls Intake Questionnaire** module for quick client onboarding, "
        "then run deeper modules for evidence-backed scoring and remediation planning."
    )
