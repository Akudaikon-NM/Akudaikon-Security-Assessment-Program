from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml


@dataclass
class Module:
    module_id: str
    title: str
    description: str
    raw: Dict[str, Any]
    path: Path

    @property
    def rating_scale(self) -> List[str]:
        logic = self.raw.get("module_logic", {}) or {}
        scale = logic.get("rating_scale") or []
        if isinstance(scale, list) and scale:
            return scale
        return ["Strong", "Satisfactory", "Less Than Satisfactory", "Deficient", "Critically Deficient"]

    @property
    def questions(self) -> List[Dict[str, Any]]:
        qs = self.raw.get("questions") or []
        if isinstance(qs, list):
            return qs
        return []


def load_modules(modules_dir: Path) -> List[Module]:
    modules: List[Module] = []
    if not modules_dir.exists():
        return modules

    for p in sorted(modules_dir.glob("*.yaml")):
        try:
            raw = yaml.safe_load(p.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                continue
            mid = raw.get("id") or p.stem
            title = raw.get("title") or mid
            desc = raw.get("description") or ""
            modules.append(Module(module_id=str(mid), title=str(title), description=str(desc), raw=raw, path=p))
        except Exception:
            # Skip malformed modules rather than breaking the app
            continue
    return modules
